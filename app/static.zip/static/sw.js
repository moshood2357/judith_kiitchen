// Service worker for admin push notifications.
// Runs independently of any open tab — this is what lets a notification
// appear even if the admin dashboard isn't open in a browser at all.

self.addEventListener("install", function (event) {
  self.skipWaiting();
});

self.addEventListener("activate", function (event) {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("push", function (event) {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (e) {
    data = { title: "New Order", body: event.data ? event.data.text() : "" };
  }

  const title = data.title || "🛎️ New Order";
  const options = {
    body: data.body || "A new order just came in.",
    icon: "/static/images/judith.png",
    badge: "/static/images/judith.png",
    vibrate: [200, 100, 200],
    requireInteraction: true,
    data: { url: data.url || "/admin/dashboard" },
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", function (event) {
  event.notification.close();
  const targetUrl =
    (event.notification.data && event.notification.data.url) ||
    "/admin/dashboard";

  event.waitUntil(
    self.clients
      .matchAll({ type: "window", includeUncontrolled: true })
      .then(function (clientList) {
        for (const client of clientList) {
          if (client.url.includes("/admin") && "focus" in client) {
            return client.focus();
          }
        }
        if (self.clients.openWindow) {
          return self.clients.openWindow(targetUrl);
        }
      }),
  );
});
